"use client"

import { User, Phone } from "lucide-react"
import { Link } from "react-router-dom"

const Header = () => {
  const handleLogout = () => {
    localStorage.removeItem("token")
    window.location.href = "/login"
  }

  return (
    <header className="app-header8">
      <div className="header-content8">
        <Link to="/client/creation" className="create-button8">
          Création d'entreprise
        </Link>
        <div className="user-actions8">
          <button className="phone-button8">
            <Phone size={16} style={{ marginRight: "8px" }} />
            06 11 95 58 23
          </button>
          <button className="user-button8" style={{ marginLeft: "15px" }}>
            <User />
          </button>
          <div className="user-dropdown8">
            <button onClick={handleLogout} className="logout-button8">
              Déconnexion
            </button>
          </div>
        </div>
      </div>
    </header>
  )
}

export default Header
