import { Link } from "react-router-dom"
import { List, Settings, Mail } from "lucide-react"

const Dashboard = () => {
  return (
    <div className="dashboard-container8">
      <div className="hero-section8">
        <h1 className="hero-title8">Démarrez</h1>
        <h2 className="hero-subtitle8">votre entreprise sans contraintes</h2>
        <p className="hero-description8">Créez et gérez votre entreprise grâce au n° 1 du marché</p>

        <div className="feature-cards8">
          <div className="feature-card8">
            <div className="feature-icon8">
              <List size={30} />
            </div>
            <h3 className="feature-title8">Personnalisation</h3>
            <p className="feature-description8">
              Faites vos choix en vous laissant guider au travers de nos formulaires.
            </p>
          </div>

          <div className="feature-card8">
            <div className="feature-icon8">
              <Settings size={30} />
            </div>
            <h3 className="feature-title8">Création</h3>
            <p className="feature-description8">
              Nous préparons <span className="highlight8">immédiatement</span> vos documents 100% personnalisés.
            </p>
          </div>

          <div className="feature-card8">
            <div className="feature-icon8">
              <Mail size={30} />
            </div>
            <h3 className="feature-title8">Téléchargement</h3>
            <p className="feature-description8">Recevez votre dossier par email prêt à imprimer en PDF ou Word.</p>
          </div>
        </div>
      </div>

      <div className="quick-actions8" style={{ marginTop: "50px" }}>
        <h2>Actions rapides</h2>
        <div className="action-buttons8">
          <Link to="/client/creation" className="action-button8">
            Créer une entreprise
          </Link>
          <Link to="/client/demarches" className="action-button8">
            Commencer une démarche
          </Link>
          <Link to="/client/support" className="action-button8">
            Contacter le support
          </Link>
        </div>
      </div>
    </div>
  )
}

export default Dashboard
