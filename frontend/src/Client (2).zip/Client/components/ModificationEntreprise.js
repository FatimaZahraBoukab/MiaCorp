const ModificationEntreprise = () => {
  return (
    <div className="modification-container8">
      <h1>Modification d'entreprise</h1>
      <p>Cette section vous permet de modifier les informations de votre entreprise existante.</p>

      <div className="placeholder-content8">
        <p>Fonctionnalité en cours de développement.</p>
      </div>
    </div>
  )
}

export default ModificationEntreprise
