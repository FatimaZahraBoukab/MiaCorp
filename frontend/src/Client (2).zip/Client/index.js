"use client"
import { Routes, Route, Navigate, useNavigate } from "react-router-dom"
import ClientLayout from "./components/ClientLayout"
import Dashboard from "./components/Dashboard"
import CreationEntreprise from "./components/CreationEntreprise"
import ModificationEntreprise from "./components/ModificationEntreprise"
import MesDemarches from "./components/MesDemarches"
import Support from "./components/Support"
import Profile from "./components/Profile"
import { useState, useEffect } from "react"
import axios from "axios"

const ClientRoutes = () => {
  return (
    <Routes>
      <Route path="/" element={<ClientLayout />}>
        <Route index element={<Dashboard />} />
        <Route path="creation" element={<CreationEntreprise />} />
        <Route path="modification" element={<ModificationEntreprise />} />
        <Route path="demarches" element={<MesDemarches />} />
        <Route path="support" element={<Support />} />
        <Route path="profile" element={<Profile />} />
        <Route path="*" element={<Navigate to="/client" replace />} />
      </Route>
    </Routes>
  )
}

// Modifier la fonction de vérification du token pour ne pas rediriger automatiquement
const Client = () => {
  // Vérifier si l'utilisateur est authentifié
  const [isAuthenticated, setIsAuthenticated] = useState(true)
  const [isLoading, setIsLoading] = useState(true)
  const navigate = useNavigate()

  useEffect(() => {
    const token = localStorage.getItem("token")
    if (!token) {
      setIsAuthenticated(false)
      setIsLoading(false)
      navigate("/login")
      return
    }

    // Vérifier la validité du token (optionnel)
    const verifyToken = async () => {
      try {
        await axios.get("http://localhost:8000/users/me", {
          headers: { Authorization: `Bearer ${token}` },
        })
        setIsAuthenticated(true)
        setIsLoading(false)
      } catch (err) {
        console.error("Token invalide:", err)
        // Ne pas supprimer automatiquement le token en cas d'erreur
        if (err.response && err.response.status === 401) {
          console.log("Problème d'authentification, mais on ne déconnecte pas l'utilisateur automatiquement")
          setIsAuthenticated(false)
        } else {
          // Pour les autres erreurs, on considère que l'utilisateur est toujours authentifié
          setIsAuthenticated(true)
        }
        setIsLoading(false)
      }
    }

    verifyToken()
  }, [navigate])

  if (isLoading) {
    return <div>Chargement...</div>
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" />
  }

  return <ClientRoutes />
}

export default Client
